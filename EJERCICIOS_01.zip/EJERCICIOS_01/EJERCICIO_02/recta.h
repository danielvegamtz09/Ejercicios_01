#include <math.h>
#include <iostream>
#ifndef RECTA_H
#define RECTA_H

#include "Line.h"


using namespace std;

class recta
{
private:
Line x1;
Line y1;


public:
recta(){
cout<< "se creo la recta"<<endl;
}

void setAsignar(float x, float y){
x1.setX(x);
x1.setY(y);



}
void setAsignar1(float x, float y){
y1.setX(x);
y1.setX(y);

}



void negates(){
float x,y,x1,y1;
x = x1.getX()*-1;
y = x1.getY()*-1;
x1 = y1.getX()*-1;
y1 = y1.getY()*-1;

cout << "negativos: " <<x <<", "<< y <<" ,"<<x1 <<", "<<y1<<endl;
}


void print(){

cout << "punto1: " <<x1.getX() <<", "<< x1.getY() <<endl;
cout << "punto2: " <<y1.getX() <<", "<< y1.getY() <<endl;

cout << "norma: " << norma() << endl;
cout<< " pendiente: "<< slope() <<endl;


}
void printV(){
int x,y,z,w;
cout << " ingrese datos de line " <<endl;

cin >> x;
cin >> y;


cout << " ingrese datos de line 2 " <<endl;

cin >> z;
cin >> w;
x1.setAsignar(x,y);
y1.setAsignar1(z,w);

}

float norma(){

float n = sqrt((x1.getX()*x1.getX())+(y1.getY()*y1.getY()));
return n;
 }

float slope(){
float m = ((y1.getY()-x1.getY()) / (x1.getX()-y1.getX()));
return m;
	}
};

#endif
