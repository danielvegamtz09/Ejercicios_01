#include "LINE.h"
#include <iostream>
using std::cout;
using std::endl;

Line::Line(float coordenada_x, float coordenada_y){
x = coordenada_x;
y = coordenada_y;



}

Line::Line(){}

void Line::setX(float coordenada_x){
x = coordenada_x;

}

void Line::setY(float coordenada_y){
y = coordenada_y;
}


float Line::getX()const{
return x;

}

float Line::getY()const{
return y;
}





void Line::printData(){


}

