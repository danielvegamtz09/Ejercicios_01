#ifndef HORAS_H
#define HORAS_H

class horas

{


private:

float mints;
float hs;
float segu;


public:

horas(float h,float m,float s);
horas();

void setM(float min);
float getM();

void setH(float hor);
float getH();

void setS(float seg);
float getS();

void print();
protected:
};

#endif
