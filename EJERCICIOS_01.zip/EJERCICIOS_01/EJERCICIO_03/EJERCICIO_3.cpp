#include <iostream>
#include <cmath>

using namespace std;
struct fecha{
int mes, anio, dia;
}f1, f2;

void PedirDatos(){
do{
cout<<"ingrese la fecha (dia-mes-anio): "; cin>>f1.dia>>f1.mes>>f1.anio;
}while((f1.mes<1 || f1.mes>12) || (f1.dia<1 || f1.dia>31));
do{
cout<<"ingrese la otra fecha (dia-mes-anio): "; cin>>f2.dia>>f2.mes>>f2.anio;
}while((f2.mes<1 || f2.mes>12) || (f2.dia<1 || f2.dia>31));
}

void CompararFechas(fecha f1, fecha f2){

int aniomayor,mesmayor,diamayor,aniomenor,mesmenor,diamenor;
int contar=0;

if (f1.anio > f2.anio){
cout<<"la fecha mayor es: "<<f1.dia<<"--"<<f1.mes<<"--"<<f1.anio;

aniomayor=f1.anio;
mesmayor=f1.mes;
diamayor=f1.dia;
aniomenor=f2.anio;
mesmenor=f2.mes;
diamenor=f2.dia;

}
else if (f1.anio < f2.anio){
cout<<"fa fecha mayor es: "<<f2.dia<<"--"<<f2.mes<<"--"<<f2.anio;

aniomayor=f2.anio;
mesmayor=f2.mes;
diamayor=f2.dia;
aniomenor=f1.anio;
mesmenor=f1.mes;
diamenor=f1.dia;

}

else{
if (f1.mes > f2.mes){
cout<<"La fecha mayor es: "<<f1.dia<<"--"<<f1.mes<<"--"<<f1.anio;
aniomayor=f1.anio;
mesmayor=f1.mes;
diamayor=f1.dia;
aniomenor=f2.anio;
mesmenor=f2.mes;
diamenor=f2.dia;
}

else if (f2.mes > f1.mes){
cout<<"La fecha mayor es: "<<f2.dia<<"--"<<f2.mes<<"--"<<f2.anio;
aniomayor=f2.anio;
mesmayor=f2.mes;
diamayor=f2.dia;
aniomenor=f1.anio;
mesmenor=f1.mes;
diamenor=f1.dia;

}

else {
if (f1.dia > f2.dia){
cout<<"la fecha mayor es: "<<f1.dia<<"--"<<f1.mes<<"--"<<f1.anio;

aniomayor=f1.anio;
mesmayor=f1.mes;
diamayor=f1.dia;
aniomenor=f2.anio;
mesmenor=f2.mes;
diamenor=f2.dia;

}
else if (f1.dia < f2.dia){
cout<<"la fecha mayor es: "<<f2.dia<<"--"<<f2.mes<<"--"<<f2.anio;

aniomayor=f2.anio;
mesmayor=f2.mes;
diamayor=f2.dia;
aniomenor=f1.anio;
mesmenor=f1.mes;
diamenor=f1.dia;

}

else {
cout<<"fechas  iguales"<<endl;
cout<<"No hay diferencia de a�os,meses o dias"<<endl;


}


}
}

for(int i=aniomenor; i<aniomayor;i++){
if(i%4==0 and i%100!=0){
contar=contar+1;
}
}

int diasmayor,diasmenor,diasdiferencia;
diasmayor=aniomayor*365 + mesmayor*30 + aniomayor;
diasmenor=aniomenor*365 + mesmenor*30 + aniomenor;

diasdiferencia=(diasmayor-diasmenor)+contar;
cout<<"\n la iferencia de a�os es  :"<<diasdiferencia/365<<" A�os "<<(diasdiferencia%365)/30<<" Meses "<<(diasdiferencia%365)%30<<" Dias"<<endl;
}

int main(){

PedirDatos();
CompararFechas(f1, f2);

cout<<"Programa terminado."<<endl;


return 0;
}
