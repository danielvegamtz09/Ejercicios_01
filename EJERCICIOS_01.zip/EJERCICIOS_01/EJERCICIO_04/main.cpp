#include <iostream>
#include "horas.h"
#include "laura.h"

using namespace std;

int main(int argc, char** argv) {

laura hr;

float h,s,m;

cout<< "ingrese h:m:s"<<endl;
cin >>h >> m>> s;
hr.setH(h,m,s);

float h1,s1,m1;

cout<< "ingrese hora 2 h:m"<<endl;
cin >>h1 >> m1>> s1;
hr.setH2(h1,m1,s1);

cout << "dif de seg: "<< hr.lahora() <<endl;


}
