#include "point.h"
#include <iostream>

using std::cout;
using std::endl;

Point::Point(float x_coord, float y_coord){
puntox = x_coord;
puntoy = y_coord;
}


Point::Point(){}
void Point::setX(float x_coord){
puntox = x_coord;
}


void Point::setY(float y_coord){
puntoy = y_coord;
}

float Point::getX()const{
return puntox;
}
float Point::getY()const{
return puntoy;
}




void Point::printData(){

cout << "El punto es: (" << puntox << ", " << puntoy << ")" << endl;
}
