#ifndef LINE_H
#define LINE_H

class Line
{

private:

float x;
float y;

public:

Line(float x_coord, float y_coord);
Line();
void setX(float x_coord);
void setY(float y_coord);

float getX()const;
float getY()const;



void printData();

};
#endif



