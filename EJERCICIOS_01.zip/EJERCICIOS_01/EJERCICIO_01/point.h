#ifndef POINT_H
#define POINT_H


class Point
{

private:

float puntox;
float puntoy;


public:

Point(float x_coord, float y_coord);
Point();
void setX(float x_coord);
void setY(float y_coord);


float getX()const;
float getY()const;

void printData();
};
#endif



