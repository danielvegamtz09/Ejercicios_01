#include <iostream>
#include "Line.h"
#include "recta.h"
using namespace std;

int main(){

recta re;
Line l;




re.printV();
re.negates();



cout <<"\nDesea hacer otra operacion? S N \n" <<endl;
cin >> rep;


}
