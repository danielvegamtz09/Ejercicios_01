#include <iostream>
#include "Point.h"
#include "vector.h"

using namespace std;

int main(){

vector vex;


float x,y,z;
char rep;

cout<<"ingrse puntos. x,y"<<endl;
cin >> x;
cin >> y;

vex.setAsignar(x,y);
vex.print();
vex.negate(x,z);









}
