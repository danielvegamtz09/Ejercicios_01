#ifndef VECTOR_H
#define VECTOR_H
#include <string>
#include <iostream>
#include <math.h>
#include "point.h"

using namespace std;
class vector

{

private:

Point x1;
Point y1;



public:
vector(){
cout << " se  creo un vector "<< endl;
}

void setAsignar(float x, float y){

x1.setX(x);
y1.setY(y);


}
void negate(float x, float y){

x = x1.getX()*-1;
y = y1.getY()*-1;


cout << "negativos: " <<x <<", "<< y <<endl;
}

void print(){

cout << "vector 1: " <<x1.getX() <<", "<< y1.getY() <<endl;
cout << "NORMA: " << norma() << endl;

}

float norma(){

float n = sqrt((x1.getX()*x1.getX())+(y1.getY()*y1.getY()));
return n;

 }

};

#endif
