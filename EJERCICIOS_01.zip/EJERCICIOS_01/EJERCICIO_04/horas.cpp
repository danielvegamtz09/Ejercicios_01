#include <iostream>
#include "horas.h"

using std::cout;
using std::endl;

horas::horas(float h, float m, float s){
hs = h;
mints = m;
segu = s;

}

horas::horas(){

}

void horas::setH(float h){
hs= h;

}

float horas::getH() {return hs;

}

void horas::setM(float m){
mints = m;

}

float horas::getM(){return mints;

}
void horas::setS(float s){
segu = s;

}

float horas::getS(){
return segu;

}

void horas::print(){

}
